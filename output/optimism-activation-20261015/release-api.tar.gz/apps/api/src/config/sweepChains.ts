import { isAddress, type Address } from "viem";
import {
  ARBITRUM_WETH_ADDRESS,
  BSC_WBNB_ADDRESS,
  ETHEREUM_WETH_ADDRESS,
  OPTIMISM_WETH_ADDRESS,
  PERMIT2_ADDRESS,
  ROBINHOOD_WETH_ADDRESS,
  WETH_ADDRESS as BASE_WETH_ADDRESS,
  getDustSweepV3TargetsForChain,
} from "./dustsweepV3Sources";

/**
 * Per-chain sweep configuration registry.
 *
 * ADDITIVE + NON-BREAKING: chainId 8453 (Base) keeps every existing constant/env exactly as
 * `dustsweep.ts` reads them today, so the Base path is byte-identical. Ethereum mainnet (chainId
 * 1) is described entirely by its own entry and is gated behind DUST_SWEEP_ENABLED_CHAIN_IDS.
 *
 * The `dustsweep.ts` request handlers resolve ONE `SweepChainConfig` per request and pass it to
 * the ~20 quote/discovery/build functions on the request path. Every such function keeps
 * `chain = BASE_CONFIG` as a default parameter, so any un-threaded call site behaves as before.
 */

export const BASE_CHAIN_ID = 8453;
export const ETHEREUM_CHAIN_ID = 1;
export const BSC_CHAIN_ID = 56;
export const ROBINHOOD_CHAIN_ID = 4663;
export const ARBITRUM_CHAIN_ID = 42161;
export const OPTIMISM_CHAIN_ID = 10;

export const NATIVE_TOKEN_SENTINEL =
  "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE" as Address;

/** Native DEX adapter selector — which on-chain quoter/router pair to probe on this chain. */
export type NativeSourceKind =
  | "uniswap_v3" // exactInput/exactInputSingle via QuoterV2
  | "pancake_v3" // same QuoterV2 quote shape, but routes build against the Pancake SmartRouter ABI
  | "uniswap_v4" // V4Quoter.quoteExactInputSingle(PoolKey); executes via Universal Router + Permit2
  | "univ2" // getAmountsOut via a UniswapV2Router02-compatible router
  | "solidly"; // Velodrome V2-style (from,to,stable,factory) routes

export type NativeSourceSpec = {
  kind: NativeSourceKind;
  dexName: string;
  /** The router the sweep executes against (also the ERC-20 spender for UniV2/self routers). */
  router: Address;
  /** Read-only quoter for uniswap_v3; UniV2 quotes off the router itself. */
  quoter?: Address;
  factory?: Address;
  feeTiers?: readonly number[];
};

export type SweepGasModel = {
  baseUnits: number;
  perRouteUnits: number;
} | null;

export type AggregatorEnableFlags = {
  kyber: boolean;
  zerox: boolean;
  lifi: boolean;
  openocean: boolean;
  // NOTE: no `odos` flag — Odos was removed as a routing provider on every chain (2026-07-27).
};

export type SweepChainConfig = {
  chainId: number;
  slug: "base" | "ethereum" | "bsc" | "robinhood" | "arbitrum" | "optimism";
  name: string;
  explorerUrl: string;

  // ── tokens ──
  weth: Address;
  usdc: Address;
  usdt: Address;
  dai: Address;
  wbtc: Address;
  /** Extra chain-native stables treated as safe output/whitelist (Base: USDbC). */
  extraStables: Address[];
  /**
   * Decimals of this chain's USDC. Base/Ethereum USDC is 6, but BSC's Binance-Peg USDC is 18 —
   * used wherever code would otherwise assume the 6-decimal convention.
   */
  usdcDecimals: number;

  // ── execution ──
  /** Env name that holds this chain's DustSwapSweepRouter V3 address. */
  routerV3Env: string;
  /** ETH is V3-only; Base still supports V1/V2 legacy lanes. */
  supportsLegacyLanes: boolean;
  /**
   * Whether this chain's deployed router supports WETH-as-passthrough (tokenIn == output token,
   * e.g. WETH swept into native ETH through the router). Requires the upgraded V3 contract. When
   * true, WETH is a first-class sweepable input; when false (Base, old contract), WETH stays
   * hidden and WETH->ETH uses the wallet-side unwrap.
   */
  supportsWethPassthrough: boolean;
  /** Server-side hard cap on tokens per sweep (min'd with the lane cap). */
  routeMaxCap: number;

  // ── discovery / economics ──
  /** Minimum per-token USD value to surface in discovery. */
  minValueUsd: number;
  /** null = use the legacy hardcoded Base gas display (zero behavior change on Base). */
  gasModel: SweepGasModel;

  // ── external service slugs ──
  kyberSlug: string; // kyberswap URL path segment
  openOceanSlug: string; // openocean v4/<slug>/swap
  dexscreenerSlug: string; // dexscreener tokens/v1/<slug>
  /** Default OpenOcean gasPrice hint in gwei for this chain. */
  openOceanGasPriceGwei: number;

  // ── aggregators ──
  aggregators: AggregatorEnableFlags;
  /** Env name that holds this chain's comma-separated aggregator target/spender allowlist. */
  allowedAggregatorTargetsEnv: string;

  // ── native DEX quoting ──
  /** null → use the existing Base native task list in getNativeQuoteCandidates (unchanged). */
  nativeSources: NativeSourceSpec[] | null;

  // ── discovery ──
  /**
   * Blockscout REST v2 base URL (…/api/v2) for the discovery balance-snapshot fallback on this
   * chain. When set, the existing Blockscout lane (previously Base-only) can also serve this
   * chain, reusing the SAME BLOCKSCOUT_API_KEYS / BLOCKSCOUT_API_KEY envs — no new key env.
   * Unset → the chain stays Alchemy-only for discovery (Ethereum/BSC behavior unchanged);
   * Base keeps resolving its URL from BLOCKSCOUT_BASE_API_V2_URL exactly as before.
   */
  blockscoutRestBaseUrl?: string;
};

function envAddress(name: string): Address {
  const value = process.env[name];
  return value && isAddress(value)
    ? (value as Address)
    : ("0x0000000000000000000000000000000000000000" as Address);
}

function numberEnv(name: string, fallback: number, min: number, max: number): number {
  const parsed = Number(process.env[name]);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.min(max, parsed));
}

function boolEnv(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  return ["1", "true", "yes"].includes(raw.toLowerCase());
}

// ── Base (8453) ──────────────────────────────────────────────────────────────
// gasModel is null and nativeSources is null so the existing Base code paths run verbatim.
export const BASE_CONFIG: SweepChainConfig = {
  chainId: BASE_CHAIN_ID,
  slug: "base",
  name: "Base",
  explorerUrl: "https://basescan.org",
  weth: BASE_WETH_ADDRESS,
  usdc: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" as Address,
  usdt: "0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2" as Address,
  dai: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb" as Address,
  wbtc: "0x0555E30da8f98308EdB960aa94C0Db47230d2B9c" as Address,
  extraStables: ["0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA" as Address], // USDbC
  usdcDecimals: 6,
  routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS",
  supportsLegacyLanes: true,
  // Base still runs the ORIGINAL V3 contract (no passthrough) — keep WETH hidden + wallet-side unwrap.
  supportsWethPassthrough: false,
  routeMaxCap: 50,
  minValueUsd: Number(process.env.DUST_SWEEP_MIN_VALUE_USD || "0.01"),
  gasModel: null,
  kyberSlug: "base",
  openOceanSlug: "base",
  dexscreenerSlug: "base",
  openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI", 0.05, 0.001, 500),
  aggregators: {
    kyber: false, // resolved via existing kyberEnabled() gate on Base — see dustsweep.ts
    zerox: false,
    lifi: false,
    openocean: false,
  },
  allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS",
  nativeSources: null,
};

// ── Ethereum mainnet (1) ─────────────────────────────────────────────────────
// Native ladder: Uniswap V3 (deepest native liquidity) + Uniswap V2 + SushiSwap V2. Everything
// else on mainnet (Curve, Balancer, Pancake, Fluid, …) is reached via the aggregator rescue path.
// All addresses re-verified live via eth_getCode before enabling (see runbook).
function ethereumConfig(): SweepChainConfig {
  return {
    chainId: ETHEREUM_CHAIN_ID,
    slug: "ethereum",
    name: "Ethereum",
    explorerUrl: "https://etherscan.io",
    weth: ETHEREUM_WETH_ADDRESS,
    usdc: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" as Address,
    usdt: "0xdAC17F958D2ee523a2206206994597C13D831ec7" as Address,
    dai: "0x6B175474E89094C44Da98b954EedeAC495271d0F" as Address,
    wbtc: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599" as Address,
    extraStables: [],
    usdcDecimals: 6,
    routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS_1",
    supportsLegacyLanes: false,
    // Ethereum deploys the UPGRADED V3 contract with WETH passthrough — WETH is first-class here.
    // Off until the passthrough-capable router is deployed (env override for staged rollout).
    supportsWethPassthrough: boolEnv("DUST_SWEEP_WETH_PASSTHROUGH_1", true),
    routeMaxCap: numberEnv("DUST_SWEEP_ROUTE_MAX_CAP_1", 15, 1, 50),
    minValueUsd: numberEnv("DUST_SWEEP_MIN_VALUE_USD_1", 1.0, 0, 1_000),
    gasModel: {
      baseUnits: numberEnv("DUST_SWEEP_GAS_UNITS_BASE_1", 120_000, 21_000, 5_000_000),
      perRouteUnits: numberEnv("DUST_SWEEP_GAS_UNITS_PER_ROUTE_1", 180_000, 21_000, 2_000_000),
    },
    kyberSlug: "ethereum",
    openOceanSlug: "eth",
    dexscreenerSlug: "ethereum",
    openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI_1", 1, 0.001, 5_000),
    aggregators: {
      kyber: boolEnv("DUST_SWEEP_ENABLE_KYBER_1", true),
      zerox: boolEnv("DUST_SWEEP_ENABLE_ZEROX_1", true),
      lifi: boolEnv("DUST_SWEEP_ENABLE_LIFI_1", true),
      openocean: boolEnv("DUST_SWEEP_ENABLE_OPENOCEAN_1", false),
    },
    allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_1",
    // Native ladder on Ethereum: Uniswap V3 (concentrated liquidity) + Uniswap V2 + SushiSwap
    // (UniswapV2 clones, via the chain-agnostic UNIV2_GENERIC calldata builder). These are the
    // deepest Uniswap-family venues. EVERYTHING else on mainnet — Curve, Balancer, PancakeSwap,
    // DODO, Fluid, Maverick, Pendle, Frax, +100 more — is reached (and price-optimized across) by
    // the aggregator rescue path (Kyber / 0x / LI.FI), whose calldata is returned by the aggregator
    // API and executed through the allowlisted aggregator routers. No per-DEX builder needed.
    nativeSources: [
      {
        kind: "uniswap_v3",
        dexName: "Uniswap V3",
        // SwapRouter02 (self-spender), QuoterV2, v3 factory — mainnet. *_1 env overrides allowed.
        router:
          process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_1 &&
          isAddress(process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_1)
            ? (process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_1 as Address)
            : ("0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45" as Address),
        quoter:
          process.env.UNISWAP_V3_QUOTER_ADDRESS_1 &&
          isAddress(process.env.UNISWAP_V3_QUOTER_ADDRESS_1)
            ? (process.env.UNISWAP_V3_QUOTER_ADDRESS_1 as Address)
            : ("0x61fFE014bA17989E743c5F6cB21bF9697530B21e" as Address),
        factory:
          process.env.UNISWAP_V3_FACTORY_ADDRESS_1 &&
          isAddress(process.env.UNISWAP_V3_FACTORY_ADDRESS_1)
            ? (process.env.UNISWAP_V3_FACTORY_ADDRESS_1 as Address)
            : ("0x1F98431c8aD98523631AE4a59f267346ea31F984" as Address),
        feeTiers: [500, 3000, 10000, 100],
      },
      {
        kind: "univ2",
        dexName: "Uniswap V2",
        router: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D" as Address,
        factory: "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f" as Address,
      },
      {
        kind: "univ2",
        dexName: "SushiSwap",
        router: "0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F" as Address,
        factory: "0xC0AEe478e3658e2610c5F7A4A2E1777cE9e4f2Ac" as Address,
      },
    ],
  };
}

// ── BNB Smart Chain (56) ─────────────────────────────────────────────────────
// Native ladder (top venues by real 24h volume, DeFiLlama 2026-07-10): PancakeSwap V3 ($253M) +
// PancakeSwap V2 ($30M) + Uniswap V3 on BSC ($24.7M) + Biswap (UniV2, quotes competitively).
// Everything else on BSC — ApeSwap, BakerySwap, MDEX, THENA, DODO, Wombat, +more — is reached
// (and price-optimized across) by the aggregator rescue path (Kyber / 0x / LI.FI). All addresses
// verified live 2026-07-10 via eth_getCode + functional quote probes (see dustsweepV3Sources.ts).
//
// BSC gotchas encoded here:
//   - native token is BNB, NOT ETH → dustsweep.ts prices gas + the WBNB hint via
//     fetchNativeUsdPrice(chain), never fetchEthUsdPrice() directly.
//   - USDT/USDC/DAI are ALL 18 decimals on BSC (usdcDecimals: 18).
//   - weth = WBNB (wrapped native). Binance-Peg WETH 0x2170…33F8 is just a normal bridged ERC20.
function bscConfig(): SweepChainConfig {
  return {
    chainId: BSC_CHAIN_ID,
    slug: "bsc",
    name: "BNB Smart Chain",
    explorerUrl: "https://bscscan.com",
    weth: BSC_WBNB_ADDRESS,
    usdc: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d" as Address, // 18 decimals (Binance-Peg)
    usdt: "0x55d398326f99059fF775485246999027B3197955" as Address, // 18 decimals
    dai: "0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3" as Address, // 18 decimals
    wbtc: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c" as Address, // BTCB, 18 decimals
    extraStables: [], // BUSD is deprecated — deliberately excluded
    usdcDecimals: 18,
    routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS_56",
    supportsLegacyLanes: false,
    // BSC deploys the UPGRADED V3 contract (same source as Ethereum's) — WBNB is a first-class
    // sweepable input that unwraps to BNB via the router passthrough leg.
    supportsWethPassthrough: boolEnv("DUST_SWEEP_WETH_PASSTHROUGH_56", true),
    routeMaxCap: numberEnv("DUST_SWEEP_ROUTE_MAX_CAP_56", 10, 1, 50),
    minValueUsd: numberEnv("DUST_SWEEP_MIN_VALUE_USD_56", 0.1, 0, 1_000),
    gasModel: {
      baseUnits: numberEnv("DUST_SWEEP_GAS_UNITS_BASE_56", 120_000, 21_000, 5_000_000),
      perRouteUnits: numberEnv("DUST_SWEEP_GAS_UNITS_PER_ROUTE_56", 180_000, 21_000, 2_000_000),
    },
    kyberSlug: "bsc",
    openOceanSlug: "bsc",
    dexscreenerSlug: "bsc",
    openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI_56", 1, 0.001, 5_000),
    aggregators: {
      kyber: boolEnv("DUST_SWEEP_ENABLE_KYBER_56", true),
      zerox: boolEnv("DUST_SWEEP_ENABLE_ZEROX_56", true),
      lifi: boolEnv("DUST_SWEEP_ENABLE_LIFI_56", true),
      openocean: boolEnv("DUST_SWEEP_ENABLE_OPENOCEAN_56", false),
    },
    allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_56",
    nativeSources: [
      {
        kind: "pancake_v3",
        dexName: "PancakeSwap V3",
        // SmartRouter (self-spender), QuoterV2, v3 factory — BSC. *_56 env overrides allowed.
        router:
          process.env.PANCAKE_V3_SWAP_ROUTER_ADDRESS_56 &&
          isAddress(process.env.PANCAKE_V3_SWAP_ROUTER_ADDRESS_56)
            ? (process.env.PANCAKE_V3_SWAP_ROUTER_ADDRESS_56 as Address)
            : ("0x13f4EA83D0bd40E75C8222255bc855a974568Dd4" as Address),
        quoter:
          process.env.PANCAKE_V3_QUOTER_ADDRESS_56 &&
          isAddress(process.env.PANCAKE_V3_QUOTER_ADDRESS_56)
            ? (process.env.PANCAKE_V3_QUOTER_ADDRESS_56 as Address)
            : ("0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997" as Address),
        factory: "0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865" as Address,
        feeTiers: [100, 500, 2500, 10000],
      },
      {
        kind: "univ2",
        dexName: "PancakeSwap V2",
        router: "0x10ED43C718714eb63d5aA57B78B54704E256024E" as Address,
        factory: "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73" as Address,
      },
      {
        kind: "uniswap_v3",
        dexName: "Uniswap V3",
        router:
          process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_56 &&
          isAddress(process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_56)
            ? (process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_56 as Address)
            : ("0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2" as Address),
        quoter:
          process.env.UNISWAP_V3_QUOTER_ADDRESS_56 &&
          isAddress(process.env.UNISWAP_V3_QUOTER_ADDRESS_56)
            ? (process.env.UNISWAP_V3_QUOTER_ADDRESS_56 as Address)
            : ("0x78D78E420Da98ad378D7799bE8f4AF69033EB077" as Address),
        factory: "0xdB1d10011AD0Ff90774D0C6Bb92e5C5c8b4461F7" as Address,
        feeTiers: [100, 500, 3000, 10000],
      },
      {
        kind: "univ2",
        dexName: "Biswap",
        router: "0x3a6d8cA21D1CF76F653A67577FA0D27453350dD8" as Address,
        factory: "0x858E3312ed3A876947EA49d572A7C42DE08af7EE" as Address,
      },
    ],
  };
}

// ── Robinhood Chain (4663) ───────────────────────────────────────────────────
// Arbitrum-stack L2, native gas token IS ETH (WETH-not-WBNB — no BSC-style rename anywhere).
// Native ladder: Uniswap V3 + Uniswap V2 — the ONLY venues with real depth on this young chain
// (GeckoTerminal 2026-07-26: Uniswap V3 USDG/WETH $48M 24h vol, $5.9M+$2.4M reserves; the next
// non-Uniswap venue, Pancake V3, tops out at ~$84K and its QuoterV2 could not be verified on
// this chain). Everything else — Pancake, SwapHood, RobinSwap, Up, Sheriff, DyorSwap, V4 pools —
// is reached (and price-optimized across) by the aggregator rescue path (Kyber / LI.FI, 0x and
// OpenOcean parked; Odos is not a provider on any chain). All addresses verified live 2026-07-26 via
// eth_getCode + functional quote probes on rpc.mainnet.chain.robinhood.com — never explorer
// labels (the canonical mainnet Uniswap addresses on this chain are FAKE stubs; see
// dustsweepV3Sources.ts).
//
// Robinhood gotchas encoded here:
//   - NO USDC/USDT/DAI exist on this chain. The default USD stable/output is USDG ("Global
//     Dollar", Paxos) 0x5fc5…d168 — 6 DECIMALS, 36k holders, $118M/day (the OTHER USDG-labeled
//     token 0x0A3B…954F is a 2-holder test deploy — never use it). usdc points at USDG;
//     usdt/dai/wbtc are zero-address sentinels (the $1-hint loop + core-token check no-op on 0x0).
//   - Cheap L2 economics (gas ~0.1–0.4 gwei, ~100ms blocks): Base-like minValueUsd, generous
//     route cap, small gas-model units.
function robinhoodConfig(): SweepChainConfig {
  const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000" as Address;
  return {
    chainId: ROBINHOOD_CHAIN_ID,
    slug: "robinhood",
    name: "Robinhood",
    explorerUrl: "https://robinhoodchain.blockscout.com",
    weth: ROBINHOOD_WETH_ADDRESS,
    usdc: "0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168" as Address, // USDG (Global Dollar), 6 dec
    usdt: ZERO_ADDRESS, // no USDT on Robinhood Chain
    dai: ZERO_ADDRESS, // no DAI on Robinhood Chain
    wbtc: ZERO_ADDRESS, // no WBTC on Robinhood Chain
    extraStables: [],
    usdcDecimals: 6, // USDG decimals — verified on-chain via decimals()=6, 2026-07-26
    routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS_4663",
    supportsLegacyLanes: false,
    // Robinhood deploys the UPGRADED V3 contract (same source family as Ethereum's) — WETH is a
    // first-class sweepable input that unwraps to native ETH via the router passthrough leg.
    supportsWethPassthrough: boolEnv("DUST_SWEEP_WETH_PASSTHROUGH_4663", true),
    // 10 tokens per sweep on this chain — matches the frontend's Robinhood selection cap
    // (DEFAULT_SELECT_LIMIT_BY_CHAIN in apps/web/src/config/sweepChainConfig.ts). Keep the two
    // in sync: the server value is the authoritative cap returned to the UI as quote.routeMaxCap.
    routeMaxCap: numberEnv("DUST_SWEEP_ROUTE_MAX_CAP_4663", 10, 1, 50),
    minValueUsd: numberEnv("DUST_SWEEP_MIN_VALUE_USD_4663", 0.01, 0, 1_000),
    gasModel: {
      baseUnits: numberEnv("DUST_SWEEP_GAS_UNITS_BASE_4663", 120_000, 21_000, 5_000_000),
      perRouteUnits: numberEnv("DUST_SWEEP_GAS_UNITS_PER_ROUTE_4663", 180_000, 21_000, 2_000_000),
    },
    kyberSlug: "robinhood", // live-verified 2026-07-26 (real WETH→USDG route)
    openOceanSlug: "robinhood", // live-verified 2026-07-26 (real quote + dex list)
    dexscreenerSlug: "robinhood", // live-verified 2026-07-26 (pairs resolve, dexId "uniswap")
    openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI_4663", 0.05, 0.001, 500),
    aggregators: {
      kyber: boolEnv("DUST_SWEEP_ENABLE_KYBER_4663", true),
      // 0x AllowanceHolder is deployed on-chain, but api.0x.org support for chainId=4663 needs a
      // KEYED quote test before enabling — default OFF until that passes (unlike ETH/BSC, where
      // the 0x quote was live-verified pre-merge).
      zerox: boolEnv("DUST_SWEEP_ENABLE_ZEROX_4663", false),
      lifi: boolEnv("DUST_SWEEP_ENABLE_LIFI_4663", true),
      openocean: boolEnv("DUST_SWEEP_ENABLE_OPENOCEAN_4663", false),
    },
    allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_4663",
    nativeSources: [
      {
        kind: "uniswap_v3",
        dexName: "Uniswap V3",
        // Official Robinhood deployment (deployer 0x9701fb0a… shipped factory+router+quoter).
        // NOT the canonical mainnet addresses — those are fake stubs on this chain.
        router:
          process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_4663 &&
          isAddress(process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_4663)
            ? (process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_4663 as Address)
            : ("0xCaf681a66D020601342297493863E78C959E5cb2" as Address),
        quoter:
          process.env.UNISWAP_V3_QUOTER_ADDRESS_4663 &&
          isAddress(process.env.UNISWAP_V3_QUOTER_ADDRESS_4663)
            ? (process.env.UNISWAP_V3_QUOTER_ADDRESS_4663 as Address)
            : ("0x33e885eD0Ec9bF04EcfB19341582aADCb4c8A9E7" as Address),
        factory: "0x1f7d7550B1b028f7571E69A784071F0205FD2EfA" as Address,
        // Deepest WETH/USDG pool sits at fee 100 ($5.9M), then 500 ($2.4M), 3000 ($0.45M).
        feeTiers: [100, 500, 3000, 10000],
      },
      {
        // Uniswap V4 — the #2 venue on this chain (~$36M/24h). Found by ACTIVITY, not labels: the
        // canonical V4 PoolManager has NO code here, and the canonical mainnet/Base Universal
        // Router addresses DO exist but are unused decoys (21 and 17 txs). The real PoolManager
        // 0x8366a39C… holds 56M transfers; the real Universal Router 0x8876789976… has 8.2M txs.
        // Verified live 2026-08-13: this quoter answers quoteExactInputSingle for WETH/USDG at
        // fee 500 / tickSpacing 10 (0.1 WETH -> 246.51 USDG) and its poolManager() == 0x8366a39C….
        kind: "uniswap_v4",
        dexName: "Uniswap V4",
        router:
          process.env.UNISWAP_V4_UNIVERSAL_ROUTER_ADDRESS_4663 &&
          isAddress(process.env.UNISWAP_V4_UNIVERSAL_ROUTER_ADDRESS_4663)
            ? (process.env.UNISWAP_V4_UNIVERSAL_ROUTER_ADDRESS_4663 as Address)
            : ("0x8876789976dEcBfCbBbe364623C63652db8C0904" as Address),
        quoter:
          process.env.UNISWAP_V4_QUOTER_ADDRESS_4663 &&
          isAddress(process.env.UNISWAP_V4_QUOTER_ADDRESS_4663)
            ? (process.env.UNISWAP_V4_QUOTER_ADDRESS_4663 as Address)
            : ("0x5c3db48cFd8352D845fac70009d714F0Ce1d7914" as Address),
        factory: "0x8366a39CC670B4001A1121B8F6A443A643e40951" as Address, // PoolManager singleton
        feeTiers: [100, 500, 3000, 10000],
      },
      {
        kind: "univ2",
        dexName: "Uniswap V2",
        router: "0x89e5DB8B5aA49aA85AC63f691524311AEB649eba" as Address,
        factory: "0x8bCEAA40b9ACdfAedf85ADf4Ff01F5AD6517937f" as Address,
      },
    ],
    // Self-hosted Blockscout REST v2, live-verified 2026-07-26 (…/addresses/{addr}/token-balances
    // returns real data). Serves as the discovery balance fallback because Alchemy's token API on
    // robinhood-mainnet is unproven; keys resolve from the existing BLOCKSCOUT_API_KEYS envs.
    blockscoutRestBaseUrl: "https://robinhoodchain.blockscout.com/api/v2",
  };
}

// ── Arbitrum One (42161) ─────────────────────────────────────────────────────
// Mature top-TVL L2 whose native gas token IS ETH — weth/IWETH9 naming everywhere (Ethereum /
// Robinhood precedent, the OPPOSITE of BSC's wbnb/IWBNB rename). ArbOS 106 (verified live via the
// ArbSys precompile), far past the ArbOS 40 Pectra floor, so EIP-7702 type-4 txs and EIP-5792
// atomic batching behave exactly as on Base. All 13 wallet-brand 7702 delegates in
// apps/web/src/lib/eip7702.ts are deployed here at the same CREATE2 addresses.
//
// Native ladder: Uniswap V3 (canonical mainnet addresses are GENUINE here — no Robinhood-style
// decoys) + SushiSwap V2. Everything else — Camelot, GMX V2, Ramses, TraderJoe, Fluid, Pendle,
// Maverick, Curve, Uniswap V4, +60 more — is reached via the aggregator rescue path, where
// OpenOcean is enabled at launch specifically for that long-tail reach (see dustsweepV3Sources.ts).
//
// Arbitrum gotchas encoded here:
//   - chain.usdc is NATIVE Circle USDC 0xaf88…5831 (6 dec), NOT the legacy bridged USDC.e
//     0xFF97…5CC8. USDC.e stays a first-class sweepable token via extraStables, never a default.
//   - usdt 0xFd08…Cbb9 now reports symbol() = "USD₮0" (Tether migrated Arbitrum USDT to the USDT0
//     standard at the SAME address; still 6 decimals). Verified live 2026-08-07.
//   - Cheap L2 economics: BASE-PARITY minValueUsd (0.01) and routeMaxCap (50). Anything stricter
//     hides real dust — discovery hides any balance under minValueUsd, and routeMaxCap is a hard
//     per-sweep token cap, so a large dust wallet would need multiple sweeps to be fully cleared.
//   - blockscoutRestBaseUrl is the PUBLIC, KEYLESS Arbitrum Blockscout instance, verified live to
//     return a complete unpaginated token-balance snapshot. It gives Arbitrum a genuine second
//     discovery lane (Ethereum/BSC have none), so an Alchemy outage degrades to a COMPLETE source
//     rather than a stale cache.
function arbitrumConfig(): SweepChainConfig {
  return {
    chainId: ARBITRUM_CHAIN_ID,
    slug: "arbitrum",
    name: "Arbitrum One",
    explorerUrl: "https://arbiscan.io",
    weth: ARBITRUM_WETH_ADDRESS,
    usdc: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831" as Address, // native Circle USDC, 6 dec
    usdt: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9" as Address, // USD₮0 (was USDT), 6 dec
    dai: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1" as Address, // 18 dec
    wbtc: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f" as Address, // 8 dec
    // Legacy bridged USDC.e — safe output/whitelist, but never the default (see note above).
    extraStables: ["0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8" as Address],
    usdcDecimals: 6, // native USDC is 6 — Base/Ethereum-like, NOT BSC's 18
    routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS_42161",
    supportsLegacyLanes: false,
    // Arbitrum deploys the UPGRADED V3 contract — WETH is a first-class sweepable input that
    // unwraps to native ETH via the router passthrough leg.
    supportsWethPassthrough: boolEnv("DUST_SWEEP_WETH_PASSTHROUGH_42161", true),
    // 10 tokens per sweep — same cap as BSC/Robinhood. Keeps 7702 batch calldata small and the
    // wallet's gas estimation predictable. Keep in sync with DEFAULT_SELECT_LIMIT_BY_CHAIN in
    // apps/web/src/config/sweepChainConfig.ts: the server value is authoritative and is returned
    // to the UI as quote.routeMaxCap. A wallet with more than 10 dust tokens clears across
    // multiple sweeps; raise via DUST_SWEEP_ROUTE_MAX_CAP_42161 (max 50) if you want fewer, bigger
    // batches.
    routeMaxCap: numberEnv("DUST_SWEEP_ROUTE_MAX_CAP_42161", 10, 1, 50),
    // BASE PARITY (0.01). Raising this HIDES sub-threshold dust from discovery.
    minValueUsd: numberEnv("DUST_SWEEP_MIN_VALUE_USD_42161", 0.01, 0, 1_000),
    gasModel: {
      baseUnits: numberEnv("DUST_SWEEP_GAS_UNITS_BASE_42161", 120_000, 21_000, 5_000_000),
      perRouteUnits: numberEnv("DUST_SWEEP_GAS_UNITS_PER_ROUTE_42161", 180_000, 21_000, 2_000_000),
    },
    kyberSlug: "arbitrum", // live-verified 2026-08-07 (real WETH→USDC route). NOT "arb".
    openOceanSlug: "arbitrum", // live-verified 2026-08-07 (dexList returns 66 DEXes)
    dexscreenerSlug: "arbitrum", // live-verified 2026-08-07 (tokens/v1/arbitrum resolves pairs)
    openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI_42161", 0.02, 0.001, 500),
    aggregators: {
      kyber: boolEnv("DUST_SWEEP_ENABLE_KYBER_42161", true),
      // 0x AllowanceHolder is deployed at the canonical address, but api.0x.org support for
      // chainId=42161 needs a KEYED quote test (header auth) before enabling — Robinhood precedent.
      zerox: boolEnv("DUST_SWEEP_ENABLE_ZEROX_42161", false),
      lifi: boolEnv("DUST_SWEEP_ENABLE_LIFI_42161", true),
      // ARBITRUM-ONLY: enabled at launch (parked on every other chain). This is the widest
      // long-tail router on this chain and is what covers Camelot/GMX/Fluid/Pendle while a native
      // Camelot (Algebra V1.9) adapter is deferred. Flip to false to kill it without a redeploy.
      openocean: boolEnv("DUST_SWEEP_ENABLE_OPENOCEAN_42161", true),
    },
    allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_42161",
    nativeSources: [
      {
        kind: "uniswap_v3",
        dexName: "Uniswap V3",
        // Canonical mainnet addresses — GENUINE on Arbitrum (verified: shared deployer
        // 0x6C9FC64A… across router/quoter/factory, all with verified contract names).
        router:
          process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_42161 &&
          isAddress(process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_42161)
            ? (process.env.UNISWAP_V3_SWAP_ROUTER_ADDRESS_42161 as Address)
            : ("0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45" as Address),
        quoter:
          process.env.UNISWAP_V3_QUOTER_ADDRESS_42161 &&
          isAddress(process.env.UNISWAP_V3_QUOTER_ADDRESS_42161)
            ? (process.env.UNISWAP_V3_QUOTER_ADDRESS_42161 as Address)
            : ("0x61fFE014bA17989E743c5F6cB21bF9697530B21e" as Address),
        factory:
          process.env.UNISWAP_V3_FACTORY_ADDRESS_42161 &&
          isAddress(process.env.UNISWAP_V3_FACTORY_ADDRESS_42161)
            ? (process.env.UNISWAP_V3_FACTORY_ADDRESS_42161 as Address)
            : ("0x1F98431c8aD98523631AE4a59f267346ea31F984" as Address),
        // 500 first — the deepest WETH/stable tier on Arbitrum.
        feeTiers: [500, 3000, 100, 10000],
      },
      {
        kind: "univ2",
        dexName: "SushiSwap",
        router: "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506" as Address,
        // factory() read live off the router 2026-08-07.
        factory: "0xc35DADB65012eC5796536bD9864eD8773aBc74C4" as Address,
      },
    ],
    // Public, KEYLESS Arbitrum Blockscout — verified live 2026-08-07 to return a complete,
    // unpaginated token-balance snapshot. Second discovery lane; keys (when present) still resolve
    // from the existing BLOCKSCOUT_API_KEYS envs.
    blockscoutRestBaseUrl: "https://arbitrum.blockscout.com/api/v2",
  };
}

// Router-from-env is read lazily (envAddress) so a SwapRouter override doesn't require a rebuild.
// nativeSources.router for uniswap_v3 falls back to the literal when the *_1 override is 0x0.
function withResolvedRouters(config: SweepChainConfig): SweepChainConfig {
  if (!config.nativeSources) return config;
  const ZERO = "0x0000000000000000000000000000000000000000".toLowerCase();
  const nativeSources = config.nativeSources.map((source) => {
    // The literal fallback is Uniswap's MAINNET SwapRouter02, so it may only be substituted on
    // Ethereum. On BSC/Robinhood that address is a different (or non-existent) contract — a
    // zeroed *_<chainId> router override there must leave the source alone rather than silently
    // point sweeps at a foreign-chain address. (Arbitrum happens to share the canonical address,
    // but it is deliberately NOT added here: its own entry already carries the correct literal,
    // so it never needs — or relies on — this substitution.)
    if (
      config.chainId === ETHEREUM_CHAIN_ID &&
      source.kind === "uniswap_v3" &&
      source.router.toLowerCase() === ZERO
    ) {
      return { ...source, router: "0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45" as Address };
    }
    return source;
  });
  return { ...config, nativeSources };
}

// OP Mainnet is V3-only and stays disabled until explicitly listed in the chain enable flag.
// USDC is Circle's native deployment; bridged USDC.e and USDT0 are separate token addresses.
function optimismConfig(): SweepChainConfig {
  const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";
  return {
    chainId: OPTIMISM_CHAIN_ID,
    slug: "optimism",
    name: "Optimism",
    explorerUrl: "https://optimistic.etherscan.io",
    weth: OPTIMISM_WETH_ADDRESS,
    usdc: "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85" as Address,
    usdt: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58" as Address,
    dai: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1" as Address,
    wbtc: "0x68f180fcCe6836688e9084f035309E29Bf0A2095" as Address,
    extraStables: [
      "0x7F5c764cBc14f9669B88837ca1490cCa17c31607" as Address, // bridged USDC.e, 6 decimals
      "0x01bFF41798a0BcF287b996046Ca68b395DbC1071" as Address, // USDT0, 6 decimals
    ],
    usdcDecimals: 6,
    routerV3Env: "DUST_SWEEP_ROUTER_V3_ADDRESS_10",
    supportsLegacyLanes: false,
    supportsWethPassthrough: boolEnv("DUST_SWEEP_WETH_PASSTHROUGH_10", true),
    routeMaxCap: numberEnv("DUST_SWEEP_ROUTE_MAX_CAP_10", 10, 1, 50),
    minValueUsd: numberEnv("DUST_SWEEP_MIN_VALUE_USD_10", 0.01, 0, 1_000),
    // Execution-gas display only. The wallet estimates the full OP fee including L1 data costs.
    gasModel: {
      baseUnits: numberEnv("DUST_SWEEP_GAS_UNITS_BASE_10", 120_000, 21_000, 5_000_000),
      perRouteUnits: numberEnv("DUST_SWEEP_GAS_UNITS_PER_ROUTE_10", 180_000, 21_000, 2_000_000),
    },
    kyberSlug: "optimism",
    openOceanSlug: "optimism",
    dexscreenerSlug: "optimism",
    openOceanGasPriceGwei: numberEnv("DUST_SWEEP_OPENOCEAN_GAS_PRICE_GWEI_10", 0.01, 0.001, 500),
    aggregators: {
      kyber: boolEnv("DUST_SWEEP_ENABLE_KYBER_10", true),
      zerox: boolEnv("DUST_SWEEP_ENABLE_ZEROX_10", false),
      lifi: boolEnv("DUST_SWEEP_ENABLE_LIFI_10", true),
      openocean: boolEnv("DUST_SWEEP_ENABLE_OPENOCEAN_10", false),
    },
    allowedAggregatorTargetsEnv: "DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_10",
    nativeSources: [
      {
        kind: "uniswap_v3",
        dexName: "Uniswap V3",
        router: envAddress("UNISWAP_V3_SWAP_ROUTER_ADDRESS_10") !== ZERO_ADDRESS
          ? envAddress("UNISWAP_V3_SWAP_ROUTER_ADDRESS_10")
          : "0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45" as Address,
        quoter: envAddress("UNISWAP_V3_QUOTER_ADDRESS_10") !== ZERO_ADDRESS
          ? envAddress("UNISWAP_V3_QUOTER_ADDRESS_10")
          : "0x61fFE014bA17989E743c5F6cB21bF9697530B21e" as Address,
        factory: envAddress("UNISWAP_V3_FACTORY_ADDRESS_10") !== ZERO_ADDRESS
          ? envAddress("UNISWAP_V3_FACTORY_ADDRESS_10")
          : "0x1F98431c8aD98523631AE4a59f267346ea31F984" as Address,
        feeTiers: [500, 3000, 100, 10000],
      },
      {
        kind: "univ2",
        dexName: "Uniswap V2",
        router: "0x4A7b5Da61326A6379179b40d00F57E5bbDC962c2" as Address,
        factory: "0x0c3c1c532F1e39EdF36BE9Fe0bE1410313E074Bf" as Address,
      },
      {
        kind: "solidly",
        dexName: "Velodrome V2",
        router: "0xa062aE8A9c5e11aaA026fc2670B0D65cCc8B2858" as Address,
        factory: "0xF1046053aa5682b4F9a81b5481394DA16BE5FF5a" as Address,
      },
    ],
    blockscoutRestBaseUrl: "https://optimism.blockscout.com/api/v2",
  };
}

const CHAIN_CONFIGS: Record<number, () => SweepChainConfig> = {
  [BASE_CHAIN_ID]: () => BASE_CONFIG,
  [ETHEREUM_CHAIN_ID]: () => withResolvedRouters(ethereumConfig()),
  [BSC_CHAIN_ID]: () => withResolvedRouters(bscConfig()),
  [ROBINHOOD_CHAIN_ID]: () => withResolvedRouters(robinhoodConfig()),
  [ARBITRUM_CHAIN_ID]: () => withResolvedRouters(arbitrumConfig()),
  [OPTIMISM_CHAIN_ID]: () => optimismConfig(),
};

/** Chains DustSweep will serve. Default: Base only. Flip DUST_SWEEP_ENABLED_CHAIN_IDS to open ETH. */
export function getEnabledSweepChainIds(): number[] {
  const raw = String(process.env.DUST_SWEEP_ENABLED_CHAIN_IDS || String(BASE_CHAIN_ID));
  const ids = raw
    .split(",")
    .map((item) => Number(item.trim()))
    .filter((id) => Number.isInteger(id) && CHAIN_CONFIGS[id] !== undefined);
  return ids.length > 0 ? Array.from(new Set(ids)) : [BASE_CHAIN_ID];
}

export function isSweepChainEnabled(chainId: number): boolean {
  return getEnabledSweepChainIds().includes(chainId);
}

/** Resolve a chain config regardless of enablement (callers gate on isSweepChainEnabled first). */
export function getSweepChainConfig(chainId: number): SweepChainConfig | null {
  const factory = CHAIN_CONFIGS[chainId];
  return factory ? factory() : null;
}

/** The canonical Permit2 (same on every chain) re-exported for convenience. */
export { PERMIT2_ADDRESS };

/** Resolve this chain's DustSwapSweepRouter V3 address from its configured env, or null. */
export function getChainRouterV3Address(config: SweepChainConfig): Address | null {
  const value = process.env[config.routerV3Env];
  return value && isAddress(value) ? (value as Address) : null;
}

/** This chain's aggregator target/spender allowlist (lowercased set). */
export function getChainAllowedAggregatorAddresses(config: SweepChainConfig): Set<string> {
  const configured = String(process.env[config.allowedAggregatorTargetsEnv] || "")
    .split(",")
    .map((item) => item.trim())
    .filter((item) => isAddress(item))
    .map((item) => item.toLowerCase());

  if (configured.length > 0) return new Set(configured);

  // Non-Base chains already have their verified V3 aggregator targets in code. Use that registry
  // as the default quote allowlist so Ethereum does not silently lose all aggregator routes when
  // DUST_SWEEP_ALLOWED_AGGREGATOR_TARGETS_1 is omitted. Base keeps its env-only behavior.
  if (config.chainId === BASE_CHAIN_ID) return new Set();

  // "odos" deliberately absent — Odos is not a routing provider on any chain, so its routers must
  // never enter the default aggregator allowlist even if a stale registry entry reappears.
  const aggregatorIds = ["kyber", "zerox", "lifi", "openocean"];
  const addresses = getDustSweepV3TargetsForChain(config.chainId)
    .filter((target) => aggregatorIds.some((id) => target.id.includes(id)))
    .flatMap((target) => [target.target, target.spender])
    .filter((address) => isAddress(address))
    .map((address) => address.toLowerCase());

  return new Set(addresses);
}
