/**
 * Aggregator API governor — shared pacing for external quote APIs (KyberSwap, 0x, LI.FI,
 * OpenOcean), which are all RPS-limited on free/low tiers.
 *
 * ADDITIVE + STANDALONE: quote candidate functions keep their own fetch/validation logic; this
 * module only decides WHEN a call may run and remembers recent results:
 *   - per-provider serial queue with a minimum interval between call starts,
 *   - load shedding: if the queue is already so deep the call would start after `MAX_QUEUE_WAIT_MS`,
 *     it is skipped (returns null) instead of stacking — a late aggregator quote is useless
 *     because the per-token quote task has its own hard timeout,
 *   - circuit breaker: an HTTP 429 (reported by the candidate fn via reportAggregatorHttpStatus)
 *     opens the breaker for a cool-off window during which calls are skipped instead of burning
 *     the provider's rate limit further,
 *   - short result cache + in-flight dedupe keyed by (provider, tokenIn, tokenOut, exact amountIn):
 *     the UI re-quotes the whole basket on every token add/remove, so unchanged tokens hit the
 *     cache instead of the API. The key uses the EXACT amount because aggregator calldata embeds it.
 */

// NOTE: Odos was removed as a routing provider on EVERY chain (2026-07-27) — DustSweep never
// calls the Odos API and never allowlists its routers. Do not re-add the id here without also
// restoring the quote candidate + ladder entry in dustsweep.ts.
export type AggregatorProviderId = "kyber" | "zerox" | "lifi" | "openocean";

/** Provider transport/rate-limit failures say nothing about a token's liquidity. */
export class AggregatorTransientError extends Error {
  override name = "AggregatorTransientError";
}

const DEFAULT_MIN_INTERVAL_MS: Record<AggregatorProviderId, number> = {
  kyber: 250, // keyless public tier is comparatively generous
  zerox: 250, // keyed tier; the pre-governor code called it fully parallel without issues
  lifi: 250,
  openocean: 1_100, // public tier is ~1 rps
};

const BREAKER_COOL_OFF_MS = 60_000;
const CACHE_TTL_MS = 45_000;
const NO_ROUTE_CACHE_TTL_MS = 30_000;
const MAX_QUEUE_WAIT_MS = 8_000;
const CACHE_SWEEP_INTERVAL_MS = 60_000;

function envMinIntervalMs(provider: AggregatorProviderId) {
  const raw = Number(process.env[`DUST_SWEEP_AGG_MIN_INTERVAL_MS_${provider.toUpperCase()}`]);
  if (Number.isFinite(raw) && raw >= 0) return Math.min(30_000, Math.round(raw));
  return DEFAULT_MIN_INTERVAL_MS[provider];
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

class ProviderGovernor {
  private queueTail: Promise<void> = Promise.resolve();
  private nextSlotAt = 0;
  private breakerOpenUntil = 0;

  constructor(
    private readonly provider: AggregatorProviderId,
    private readonly chainId: number,
  ) {}

  isBreakerOpen() {
    return Date.now() < this.breakerOpenUntil;
  }

  tripBreaker() {
    this.breakerOpenUntil = Date.now() + BREAKER_COOL_OFF_MS;
    console.warn(
      `[dustsweep/aggregator] ${this.provider} (chain ${this.chainId}) rate-limited (429) — pausing calls for ${BREAKER_COOL_OFF_MS / 1000}s`,
    );
  }

  /**
   * Run `fn` at the provider's pace (serialized, min interval between call starts), or return
   * null without running it when the breaker is open or the queue is already too deep.
   */
  async schedule<T>(fn: () => Promise<T>, deadlineAt?: number): Promise<T | null> {
    if (this.isBreakerOpen()) return null;

    const now = Date.now();
    const projectedStart = Math.max(now, this.nextSlotAt);
    if (projectedStart - now > MAX_QUEUE_WAIT_MS || (deadlineAt !== undefined && projectedStart >= deadlineAt)) return null;
    this.nextSlotAt = projectedStart + envMinIntervalMs(this.provider);

    const previous = this.queueTail;
    let release: () => void = () => {};
    this.queueTail = new Promise<void>((resolve) => {
      release = resolve;
    });

    await previous;
    try {
      // Fetch duration can make the real queue wait much longer than the pacing-slot estimate.
      // Never start obsolete work after the caller's deadline or the queue's own wait cap.
      if (Date.now() - now > MAX_QUEUE_WAIT_MS || (deadlineAt !== undefined && Date.now() >= deadlineAt)) return null;
      const wait = projectedStart - Date.now();
      if (wait > 0) await sleep(wait);
      if (this.isBreakerOpen() || Date.now() - now > MAX_QUEUE_WAIT_MS || (deadlineAt !== undefined && Date.now() >= deadlineAt)) return null;
      return await fn();
    } finally {
      release();
    }
  }
}

// Keyed `provider:chainId` so a rate-limit storm on one chain never pauses another —
// a mainnet 429 must not trip the breaker for Base traffic (and vice versa).
const governors = new Map<string, ProviderGovernor>();
const DEFAULT_CHAIN_ID = 8453;

type CacheEntry = { value: unknown; expiresAt: number };
// `ran=false` means the provider did not answer (skipped or transient failure). Every caller
// sharing the deduped promise must see that, not just the first one.
type GovernedOutcome = { value: unknown; ran: boolean };
const resultCache = new Map<string, CacheEntry>();
const inFlight = new Map<string, Promise<GovernedOutcome>>();
let lastCacheSweepAt = 0;

function getGovernor(provider: AggregatorProviderId, chainId: number) {
  const key = `${provider}:${chainId}`;
  let governor = governors.get(key);
  if (!governor) {
    governor = new ProviderGovernor(provider, chainId);
    governors.set(key, governor);
  }
  return governor;
}

function sweepCacheIfDue() {
  const now = Date.now();
  if (now - lastCacheSweepAt < CACHE_SWEEP_INTERVAL_MS) return;
  lastCacheSweepAt = now;
  for (const [key, entry] of resultCache) {
    if (entry.expiresAt <= now) resultCache.delete(key);
  }
}

/**
 * Candidate functions call this after each fetch so a 429 opens the provider's breaker.
 * Authentication/WAF, timeout and server failures are retryable too; they cannot establish
 * that a token has no liquidity. Normal provider no-route validation stays in the adapter.
 */
export function reportAggregatorHttpStatus(
  provider: AggregatorProviderId,
  status: number,
  chainId: number = DEFAULT_CHAIN_ID,
) {
  if (status === 429) getGovernor(provider, chainId).tripBreaker();
  if ([401, 403, 408, 425, 429].includes(status) || status >= 500) {
    throw new AggregatorTransientError(`Aggregator ${provider} temporarily unavailable (HTTP ${status})`);
  }
}

/**
 * Governed call wrapper: cache → in-flight dedupe → breaker/pace → run → cache result.
 * Returns null when the provider is cooling off or the queue is too deep right now; those
 * nulls are NOT cached (a later attempt should retry), while a null from `fn` itself
 * ("no route") is cached briefly. `onSkipped` fires for skipped calls and retryable provider
 * failures so callers cannot persist an unanswered liquidity question as "no route".
 */
export async function governAggregatorCall<T>(
  provider: AggregatorProviderId,
  cacheKey: string,
  fn: () => Promise<T | null>,
  onSkipped?: () => void,
  chainId: number = DEFAULT_CHAIN_ID,
  deadlineAt?: number,
): Promise<T | null> {
  sweepCacheIfDue();
  // chainId in the key so the same (tokenIn,tokenOut,amount) on two chains never share a cache
  // entry or an in-flight promise — calldata and prices are chain-specific.
  const key = `${provider}:${chainId}:${cacheKey}`;

  const cached = resultCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.value as T | null;

  let outcomePromise = inFlight.get(key);
  if (!outcomePromise) {
    outcomePromise = (async (): Promise<GovernedOutcome> => {
      let ran = false;
      let value: T | null = null;
      try {
        value = await getGovernor(provider, chainId).schedule(async () => {
          ran = true;
          return fn();
        }, deadlineAt);
      } catch (error) {
        if (!(error instanceof AggregatorTransientError)) throw error;
        // The provider ran but did not answer the liquidity question. Treat this like
        // a skipped call for every deduped caller, without poisoning either negative cache.
        ran = false;
      } finally {
        inFlight.delete(key);
      }
      if (ran) {
        resultCache.set(key, {
          value,
          expiresAt: Date.now() + (value === null ? NO_ROUTE_CACHE_TTL_MS : CACHE_TTL_MS),
        });
      }
      return { value, ran };
    })();
    inFlight.set(key, outcomePromise);
  }

  const outcome = await outcomePromise;
  if (!outcome.ran) onSkipped?.();
  return outcome.value as T | null;
}
